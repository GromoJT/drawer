import { TextField } from "@mui/material"
import React from "react"
import './styles/MuiListElementStyles.css'

const MuiDrawerListElement = (props) => {
  return (
    <>
      <div className="listImageContainer" onClick={() => {props.handleClickOnPanon(props.id)}}>
        <img 
            src={props.img}
            loading="lazy"
            alt={props.title}
        />
        {
          props.edit
          ?
          <div className="listImageTitle">
            {props.title}
          </div>
          :
          <form onSubmit={e => { e.preventDefault(); }}  noValidate autoComplete="off" style={{color:'white'}}>
            <TextField 
              size="small" 
              defaultValue={props.title} 
              onChange={e => {props.handlePanosUpdate(e,props.pid)}}
              sx={{paddingLeft:'0.5rem'}}
              fullWidth
              required
              InputProps={{
                style:{color:'white'}
              }}/>
            </form>
        }
        
      </div>
      
    </>
  )
}

export default MuiDrawerListElement


