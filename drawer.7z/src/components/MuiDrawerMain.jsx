import { Box, Divider, IconButton, TextField, Typography } from '@mui/material'

import React, { useEffect, useState } from 'react'
import "./styles/MuiDrawerMainStyles.css";
import MuiDrawerElement from './MuiDrawerElement';
import WindowIcon from '@mui/icons-material/Window';
import ViewListIcon from '@mui/icons-material/ViewList';
import EditIcon from '@mui/icons-material/Edit';
import CheckIcon from '@mui/icons-material/Check';

//import Data from '../data/data'



const MuiDrawerMain = (props) => {

 
  

    const [gridView,setGridView] = useState(true)
    const [edit,setEdit] = useState(true)
    const [items,setItems] = useState([])
    //console.log(items)
    const [title,setTitle] = useState("TEST")
    const [description,setDescription] = useState("....")
    const [galleryContentUrl,setGalleryContentUrl] = useState("")
    const [galleryId,setGalleryId] = useState("")

    const [tempDescription,setTempDescription] = useState("")
    const [tempPanosNames,setTempPanosNames] = useState([])
    const [activePanon,setActivePanon] = useState(0)

    const [changeAccumulator,setChangeAccumulator] = useState([])
    const [updateFlag,setUpdateFlag] = useState(false)

    let ch = []

    const changeView = () =>{
        
        setGridView(!gridView)
    }

    const handleSetEdit = () =>{
        //console.log("Ustawiam tymczasowe dane")
        setTempDescription(description)
        handleSetTempPanosNames()
        
        setEdit(!edit);
    }

    const handleSetTempPanosNames = () =>{
        for(let i = 0 ; i < items.length ; i++){
            //console.log(items[i].PName)
            setTempPanosNames( (tempPanosNames) => [...tempPanosNames ,{ name : items[i].PName }  ])
        }
        
        
    }

    const handleDescriptionUpdateMSG = () =>{
        if(description!==tempDescription){
            setUpdateFlag(true)
            //console.log(" description update attempt")

            ch.push({
                holderId : galleryId,
                propertyName:"description",
                type : "GALLERY",
                value : description
            })
        

        console.log(ch)    
    }
        
    }

    const handlePanosUpdateMSG = () => {
        for( let i = 0 ; i< tempPanosNames.length ; i++){
   
            if(items[i].PName !== tempPanosNames[i].name){
                setUpdateFlag(true)
                let tempType  
                if(items[i].PType == "video/mp4"){
                    tempType = "VIDEO"
                }
                else{
                    tempType = "PANO"
                }

                //console.log("Pano name change atempt")
                ch.push({
                    holderId : items[i].SID,
                    propertyName:"panoName",
                    type : "PANO",
                    value : items[i].PName
                })
            }
        }
    }
    
    
    const handleFinishEdit = () =>{
        setEdit(!edit);
        handleDescriptionUpdateMSG();
        handlePanosUpdateMSG();
        
        
            let msg = {
                command : "Update",
                galleryId : galleryId,
                ch : ch
            }
            //console.log(msg)
            window.top.postMessage(msg,'*') 
            
        
        
        ch = []
        setTempPanosNames([])
        setTempDescription("")
        setChangeAccumulator([])
    }

    

    const handleTitleUpdate = (event)=>{
        setTitle(event.target.value)
    }

    const handleDescriptionUpdate = (event)=>{
        setDescription(event.target.value)
    }

    const handlePanosUpdate = (event,id) => {
        
        //console.log(event.target)
        let ChangedPanonId = id
        //console.log(ChangedPanonId);
        items[ChangedPanonId].PName=event.target.value
        
    }

    const initDescription = (e) =>{
        setDescription(e.data.GalleryDescription)
    }

    
    const initTitle = (e) =>{
        setTitle(e.data.GalleryName)
    }
    
    const initItems = (e,videos) => {
        //console.log(e.data.GalleryPanos)
        setItems(e.data.GalleryPanos)
        for(let i = 0 ; i<videos.length ; i++ ){
            setItems( (items) => [...items ,{ CID : videos[i].CID, PName : videos[i].PName, PThumbnailId : videos[i].PThumbnailId, PType : videos[i].PType, SID: videos[i].SID }  ])
        }
        
    }

    const initGalleryContentUrl = (e) =>{
        setGalleryContentUrl(e.data.GalleryContentUrl)
    }
    
    const initGalleryId = (e) =>{
        setGalleryId(e.data.GalleryID)
    }

    const handleClickOnPanon = (panomId,key) => {
        if(edit){
            //console.log("CLICK " + panomId)
            let msg = {
                command : "PanoClicked",
                id : panomId
            }
        window.top.postMessage(msg,'*') ;
        }
        //console.log(key)
        setActivePanon(key)
        
    }

    

    useEffect(()=>{
        //console.log("Ustawiam listener...")
        window.addEventListener('message',function(e){
            //console.log(e.origin)
            if(e.origin !== "https://social-loops-show-78-9-119-83.loca.lt") return;
            //console.log("message recived!")
            //console.log(e)
            initTitle(e)
            initDescription(e)
            initGalleryId(e)
            initGalleryContentUrl(e)
            initItems(e,e.data.GalleryVideos)
            //test234

        },false);

        let msg = {
            command:"readyToGetData",

        }
        window.top.postMessage(msg,'*') ;

        return () =>{
            window.removeEventListener('message',initDescription(e),false);
        };

    },[])
    
    
    
  return (
    <Box 
        className='prevent-select'
        textAlign='center' 
        role='presentation'
        sx={{
            color:'black',
            height:'100vh',
            width:props.myWidth,
            background: "linear-gradient(90deg, rgba(72,71,70,0.896796218487395) 1%, rgba(25,24,22,0.9023984593837535) 50%, rgba(41,41,41,0.9023984593837535) 99%)",
            backdropFilter: "blur(6px)",
        }}
    >
        <Box className='main-box'>
            <Box className='title-area'>
                <Typography variant='h5' component='div'>
                    {title}        
                </Typography>
            </Box>
            <Box className='description-area'>
                {
                    edit
                    ?
                    <Typography id="description-text" variant='p' component='div'>
                       {description}
                    </Typography>
                    :
                    <form noValidate autoComplete="off" style={{color:'white'}}>
                        
                        <TextField
                            className='custom-textfield'
                            defaultValue={description}
                            onChange={handleDescriptionUpdate}
                            fullWidth
                            required
                            InputProps={{
                                style:{
                                    color:'white',
                                    fontSize: 'small',
                                    letterSpacing:'0px',
                                    
                                }
                            }}
                            sx={{
                                letterSpacing:"0px",
                                lineHeight:'-1'
                            }}
                            variant='standard'
                            multiline
                        />
                    </form>
                    
                }
                
            </Box>

            

            <Box className='mods-icons-box'>
            
            {edit
            ?
            <>
            {
                gridView?
                <>
                    <IconButton
                    className='custom-iconButton'
                    disabled
                    edge='start'
                    color='inherit'>
                        <WindowIcon/>
                    </IconButton>
                
                    <IconButton
                    className='custom-iconButton'
                    onClick={changeView}
                    edge='start'
                    color='inherit'>
                        <ViewListIcon />
                    </IconButton>
                </>
                :
                <>
                    <IconButton
                    edge='start'
                    color='inherit'
                    onClick={changeView}>
                        <WindowIcon/>
                    </IconButton>
                
                    <IconButton
                    disabled
                    edge='start'
                    color='inherit'>
                        <ViewListIcon />
                    </IconButton>
                </>
            }
            </>
            :
                null
            }
            
                
                {
                    edit
                    ?
                    <IconButton
                    edge='start'
                    color='inherit'
                    onClick={handleSetEdit}>
                       <EditIcon />
                   </IconButton>
                    :
                    <IconButton
                    edge='start'
                    color='inherit'
                    onClick={handleFinishEdit}>
                        <CheckIcon />
                    </IconButton>
                }

                
            </Box>

            <Box className='panos-area' >
                
                {
                    items.map( (item,index) => {
                        
                        return(
                            <MuiDrawerElement key={index} gridView={gridView} pid={index} img={galleryContentUrl+galleryId+'/'+item.PThumbnailId} MediaType={item.PType} id={item.SID} title={item.PName} edit={edit} activePanon={activePanon} handleClickOnPanon={handleClickOnPanon} handlePanosUpdate={handlePanosUpdate} />
                        )
                    }) 
                }
            
            </Box>   
            
        </Box>
        
    </Box>     
  )
}

export default MuiDrawerMain



