import { TextField } from "@mui/material"
import React from "react"
import './styles/MuiGridElementStyles.css'

const MuiDrawerGridElement = (props) => {
  return (
    <>
      <div className="gridImageContainer" onClick={() => {props.handleClickOnPanon(props.id)}}>
        <img 
            src={props.img}
            loading="lazy"
            alt={props.title}
        />
      </div>
      {
          props.edit
          ?
          <div className="gridImageTitle">
            {props.title}
          </div>
          :
          <form onSubmit={e => { e.preventDefault(); }}  noValidate autoComplete="off" style={{color:'white'}}>
              <TextField 
                className="gridElementTitleEdit"
                size="small" 
                onChange={e => {props.handlePanosUpdate(e,props.pid)}}
                defaultValue={props.title} 
                width="85%"
                required
                InputProps={{
                  style:{color:'white',margin:'none',padding:'0',}
                }}
                
                />
          </form>  
        }
      
      
    </>
  )
}

export default MuiDrawerGridElement