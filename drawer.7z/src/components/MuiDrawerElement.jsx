import { TextField } from "@mui/material"
import React from "react"
import './styles/MuiDrawerElementStyles.css'

const MuiDrawerElement = (props) => {
   
    let givenSRC = props.img
    let defSrc = "https://dev.theviewer.co/html/theViewer/content/defaultGalleryThumbnail.png"
    let cn="ElImg"
    let EC=''
    let imgH,imgW
    //console.log(props.MediaType)

    if(props.MediaType == "video/mp4"){
        givenSRC = defSrc
    }
    if(props.activePanon == props.pid) {
        cn= cn + " active"
    }
    if(props.gridView == true){
        EC = "ElementContainer"
        imgH = 80
        imgW = 143
    }
    else{
        EC = "ElementContainerList"
        imgH = 110
        imgW = 195
    }
    
  return (
    <>
    
      <div className={EC} onClick={() => {props.handleClickOnPanon(props.id,props.pid)}}>
        <img 
        className={cn}
            style={{
                height:imgH,
                width:imgW,
            }}
            src={givenSRC}            
            loading="lazy"
            alt={props.title}
        />
        {
          props.edit
          ?
          <div className="ElementPanosTitle">
            {props.title}
          </div>
          :
          <form onSubmit={e => { e.preventDefault(); }}  noValidate autoComplete="off" style={{color:'white'}}>
              <TextField 
                size="small" 
                onChange={e => {props.handlePanosUpdate(e,props.pid)}}
                defaultValue={props.title} 
                width="85%"
                required
                InputProps={{
                    style:{
                        color:'white',
                        fontSize: 'small',
                        letterSpacing:'0px',
                    }
                }}
                sx={{
                    letterSpacing:"0px",
                    margin: 0,
                }}
                variant='standard'
                
                />
          </form>  
        }
      </div>
      
    </>
  )
}

export default MuiDrawerElement