const Data = [

    {
        id:1,
        img:"https://thispersondoesnotexist.com/image",
        title:"test 1 test 1 test 1"
    },
    {
        id:2,
        img:"https://picsum.photos/200",
        title:"TEST 2"
    },
    {
        id:3,
        img:"https://random.dog/e5ccde95-9fce-4eaf-8500-5d5fbe43cb56.jpg",
        title:"TEST 3"
    },
    
    {
        id:4,
        img:"https://purr.objects-us-east-1.dream.io/i/ddJ2vs2.jpg",
        title:"TEST 4"
    },
    {
        id:5,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:6,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:7,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:8,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:9,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:10,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:11,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:12,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:13,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:14,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:15,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:16,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },
    {
        id:17,
        img:"https://thispersondoesnotexist.com/image",
        title:"TEST 1"
    },

]
export default Data;